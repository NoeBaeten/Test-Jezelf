<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>
		
	</title>
	<link rel="stylesheet" href="css/ello.css">
</head>
<body class="profile">
	
	

	<div class="profile_details">
		<img src="" alt="">	
		<h1>name here</h1>
		<p>bio here</p>
	</div>
</body>
</html>