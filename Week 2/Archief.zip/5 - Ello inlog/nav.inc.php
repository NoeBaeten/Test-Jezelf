<?php
	
?>
<nav>
	
	<!--<p class="welcome">Welcome back! <a href="logout.php">Log out?</a></p>-->
			
	<form action="" method="post">
		<input class="input" type="text" name="username" placeholder="Your username">
		<input class="input" type="password" name="password" placeholder="Your password">
		<button class="button" type="submit">Log in</button>
	</form>
	
</nav>