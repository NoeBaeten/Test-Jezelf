<?php

	$users = [
		
		[	"name" => "The artist", 
			"bio" => "thereart.ro • art to refresh mindsets", 
			"picture" => "https://s3.amazonaws.com/uifaces/faces/twitter/tomaslau/128.jpg"
		],


		[	"name" => "Jean claude", 
			"bio" => "LA-based fashion and editorial photographer | All photos are mine unless otherwise noted.", 
			"picture" => "https://s3.amazonaws.com/uifaces/faces/twitter/jina/128.jpg"
		],

		[	"name" => "Jean claude", 
			"bio" => "LA-based fashion and editorial photographer | All photos are mine unless otherwise noted.", 
			"picture" => "https://s3.amazonaws.com/uifaces/faces/twitter/9lessons/128.jpg"
		],

		[	"name" => "Jean claude", 
			"bio" => "LA-based fashion and editorial photographer | All photos are mine unless otherwise noted.", 
			"picture" => "https://s3.amazonaws.com/uifaces/faces/twitter/shalt0ni/128.jpg"
		],

		[	"name" => "Jean claude", 
			"bio" => "LA-based fashion and editorial photographer | All photos are mine unless otherwise noted.", 
			"picture" => "https://s3.amazonaws.com/uifaces/faces/twitter/pixeliris/128.jpg"
		],

		[	"name" => "Jean claude", 
			"bio" => "LA-based fashion and editorial photographer | All photos are mine unless otherwise noted.", 
			"picture" => "https://s3.amazonaws.com/uifaces/faces/twitter/kaibrach/128.jpg"
		]
	
	];

?>