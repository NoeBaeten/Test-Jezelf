<?php
	
	$products = [
					[
						"photo" => "http://d39qw52yhr4bcj.cloudfront.net/catalog/product/cache/9/small_image/200x200/9df78eab33525d08d6e5fb8d27136e95/0/5/0575-shapesortingcubecomp_1.jpg",
						"name" => "Shapesortin Cube",
						"info" => "€10,-"
					],
					[
						"photo" => "http://d39qw52yhr4bcj.cloudfront.net/catalog/category/activity-toys-for-toddlers_1.jpg",
						"name" => "Toddler Toys",
						"info" => "€60,-"
					],
					[
						"photo" => "http://d39qw52yhr4bcj.cloudfront.net/catalog/product/cache/9/small_image/200x200/9df78eab33525d08d6e5fb8d27136e95/e/0/e00286-10-eybusyballdropbaby1comp.jpg",
						"name" => "Ball Drop Thingy",
						"info" => "€20,-"
					],
					
					
				];
?>